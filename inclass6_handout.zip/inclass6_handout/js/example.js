// ADD NEW ITEM TO END OF LIST
var ul = document.getElementById('page').getElementsByTagName('ul')[0];
var el = document.createElement('li');
var text = document.createTextNode('cream');
el.appendChild(text);
el.setAttribute('id','five');
ul.appendChild(el);

// ADD NEW ITEM START OF LIST
var el = document.createElement('li');
var text = document.createTextNode('kale');
el.appendChild(text);
ul.prepend(el);

// ADD A CLASS OF COOL TO ALL LIST ITEMS
var i = document.querySelectorAll('li');
var j;
for (j = 0; j < i.length ; j++)
{
  i[j].className = 'cool';
}


// ADD NUMBER OF ITEMS IN THE LIST TO THE HEADING
var head =  document.querySelector('h2');
var tl = head.firstChild.nodeValue;
var num = i.length;
var newHead = tl + '<span>' + num + '</span>';
head.innerHTML = newHead;
